
class SaveRegistry:
    def __init__(self):
        pass

    def register(self, savable_widget, exercise_name):
        pass

    def save(self, exercise_name):
        return True
